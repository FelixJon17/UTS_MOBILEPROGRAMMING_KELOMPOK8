package com.example.fitnessapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
